package tp.dal;

public interface IvalueLoader {
	double getDolarValue();
}
