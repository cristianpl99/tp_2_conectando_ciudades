package tp.dal;

import java.util.List;
import tp.logic.City;

public interface Idata {
	List<City> getCities();
	List<String> getProvinces();
}
